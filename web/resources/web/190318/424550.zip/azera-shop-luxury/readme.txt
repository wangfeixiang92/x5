# Azera Shop Luxury

Contributors: codeinwp, themeisle

Tags: one-column, two-columns, right-sidebar, custom-background, custom-colors, custom-menu, featured-images, front-page-post-form, full-width-template, rtl-language-support, threaded-comments, translation-ready

Requires at least:	3.3.0

Tested up to:		4.6.1

## License #

Azera Shop Luxury WordPress theme, Copyright (C) 2017 ThemeIsle.com
Azera Shop Luxury WordPress theme is licensed under the GPL2.

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License.
The exceptions to this license are as follows:

# Images

    License:
    All pixabay.com images are licensed under the terms of the Creative Commons Zero, http://creativecommons.org/publicdomain/zero/1.0/

    Images from screenshot:
        * https://pixabay.com/en/stainless-background-white-bracelet-878357/

    File:   /assets/img/background-images/background.jpg
    Source: https://pixabay.com/en/stainless-background-white-bracelet-878357/
   
