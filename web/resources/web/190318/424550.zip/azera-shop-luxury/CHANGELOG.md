
### 1.0.7 - 12/12/2016
**Changes:** 
- Update readme file images license
- Fixed issues with mixed lists
- Fixed issue with broken quantity input on cart page

### 1.0.6 - 25/11/2016
**Changes:** 
- Update style.css

### 1.0.5 - 25/11/2016
**Changes:** 
- Added grunt
- Fixed grunt errors

### 1.0.3 - 07/11/2016
**Changes:** 
- #44

### 1.0.2 - 01/11/2016
**Changes:** 
- Improved Shop page layout

