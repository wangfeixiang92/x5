var local_database = [{
    imgSrc: "/images/food.jpg",
    foodName: "挪威深海三文鱼",
    price: 180.00,
    num:1
}, {
    imgSrc: "/images/food.jpg",
    foodName: "大大的牛排",
    price: 200.00,
    num:3
}, {
    imgSrc: "/images/food.jpg",
    foodName: "金牌酸辣鱼粉",
    price: 300.00,
    num:8
}, {
    imgSrc: "/images/food.jpg",
    foodName: "金牌酸辣鱼粉",
    price: 300.00,
    num:8
}, {
    imgSrc: "/images/food.jpg",
    foodName: "金牌酸辣鱼粉",
    price: 300.00,
    num:8
}, {
    imgSrc: "/images/food.jpg",
    foodName: "金牌酸辣鱼粉",
    price: 300.00,
    num:8
}, {
    imgSrc: "/images/food.jpg",
    foodName: "金牌酸辣鱼粉",
    price: 300.00,
    num:8
}, {
    imgSrc: "/images/food.jpg",
    foodName: "金牌酸辣鱼粉",
    price: 300.00,
    num:8
}
]
module.exports = {
    postList: local_database
}